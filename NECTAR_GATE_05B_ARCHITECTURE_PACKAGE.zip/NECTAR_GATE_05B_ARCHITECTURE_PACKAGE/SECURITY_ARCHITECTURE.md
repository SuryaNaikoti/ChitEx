# NECTAR — Security Architecture Specification
**Document Reference:** `docs/architecture/SECURITY_ARCHITECTURE.md`  
**Milestone:** Gate 05B — Backend Architecture & Integration Preparation  
**Classification:** Confidential — Engineering & Security Architecture  
**Author:** Principal Software Architect, Backend Architect & Security Engineer  

---

## 1. Executive Security Summary & Threat Model

Nectar is a voice-first social discovery and virtual gifting platform operating primarily in the Indian market. Its threat model encompasses:
1. **Financial Fraud & Ledger Tampering:** Unauthorized coin crediting, race-condition gift issuance, fabricated payment webhooks, double spending, and unauthorized payout claims.
2. **Identity & Age Verification Impersonation:** Minors (<18) attempting access to voice/monetization features, bypassing age verification or falsifying Indian DPDP Act 2023 compliance.
3. **Voice Audio Eavesdropping & Interception:** Unauthorized access to WebRTC media streams, token spoofing, or rogue participant injection into LiveKit voice rooms.
4. **Harassment, Abuse & Stalking:** User-to-user harassment, unsolicited calls, spam matching, evasion of user blocks, and leakage of personal identifiers (phone numbers, IP addresses, exact locations).
5. **Data Exposure & PII Leakage:** Exposure of user KYC documents (for creator payouts), phone numbers, transaction histories, or private direct messages through misconfigured API endpoints or database queries.

### Threat Model Matrix (STRIDE Analysis)

| Threat Category | Target Asset | Attack Vector | Security Countermeasure |
| :--- | :--- | :--- | :--- |
| **Spoofing** | User Identity, Razorpay Webhooks | Forged JWTs, fake webhook HTTP requests | Supabase Auth server-side verification, Razorpay HMAC-SHA256 signature validation with webhook secret |
| **Tampering** | Coin Balances, Call Rates | Client-side state manipulation, parameter tampering | Server-authoritative PostgreSQL ledger (`SELECT FOR UPDATE`), zero trust of client balances or pricing |
| **Repudiation** | Gift Transfers, Creator Payouts | Disputing sent gifts or processed payouts | Immutable double-entry ledger (`wallet_transactions`), cryptographic hash linkage, audit logs |
| **Information Disclosure** | User Phone, KYC, Live Audio | RLS bypass, unsecured LiveKit rooms, PII leakage | Strict PostgreSQL RLS, short-lived LiveKit JWTs (10 min), PII masking (last 4 digits only), encrypted KYC storage |
| **Denial of Service** | Matching Queues, Call Signalling | Connection flooding, socket exhaustion | Upstash Redis sliding-window rate limiting, maximum 1 active queue per user, LiveKit connection limits |
| **Elevation of Privilege** | Admin/Moderator Controls | Tampering with user metadata or role claims | Database-level RBAC (`profiles.role`), server-only service-role bypass, no client-writable role columns |

---

## 2. Authentication & Authorization Boundaries

### 2.1 Principle of Least Privilege
1. **Client Application (Browser/PWA):**
   - Accesses Supabase via `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
   - All client queries are subject to PostgreSQL **Row Level Security (RLS)** using `auth.uid()`.
   - Never receives or uses `SUPABASE_SERVICE_ROLE_KEY`.
   - Auth tokens are maintained in secure, `httpOnly`, `SameSite=Lax`, `Secure` cookies managed by `@supabase/ssr`.
2. **Next.js Route Handlers (Serverless/Node.js):**
   - Authenticate requests by reading session cookies via `createClient` from `@supabase/ssr`.
   - Use `SUPABASE_SERVICE_ROLE_KEY` **strictly within isolated backend services** (e.g., webhook handlers, administrative reconciliations, system ledger balance adjustments) that cannot be directly invoked by unauthenticated users.
3. **External Services (LiveKit, Razorpay, Gemini):**
   - LiveKit API keys/secrets are server-only. Client receives an ephemeral WebRTC access token (TTL: 10 minutes, room-scoped, no administrative grant).
   - Razorpay Key Secret is server-only. Client receives only `order_id` and public `key_id`.
   - Gemini API keys are server-only. Clients submit text/audio for moderation via Next.js proxy routes.

### 2.2 Role-Based Access Control (RBAC) Matrix

| Entity / Resource | Anonymous | Authenticated (User) | Authenticated (Creator) | Platform Moderator | Platform Admin |
| :--- | :---: | :---: | :---: | :---: | :---: |
| Public Discovery Cards | Read Only | Read Only | Read Only | Read Only | Read Only |
| User Profile (Own) | None | Read / Update | Read / Update | Read / Update | Read / Update |
| User Profile (Other) | None | Read (Public fields) | Read (Public fields) | Read (Includes safety flags) | Read (Full) |
| Coin Balances | None | Read (Own balance) | Read (Own balance) | Read (Audit view) | Read (Full) |
| Ledger Transactions | None | Read (Own entries) | Read (Own entries) | Read (Audit view) | Read / Reconcile |
| Call Sessions | None | Read (Participating) | Read (Participating) | Read (Metadata only) | Read / Terminate |
| LiveKit Voice Rooms | None | Join (Valid token) | Join (Valid token) | Join (Silent observe if flagged) | Admin control |
| Creator Payout Info | None | None | Read / Update (Own) | Read (Verification) | Read / Approve |
| Moderation Reports | None | Create (Submit report) | Create (Submit report) | Read / Review / Resolve | Read / Manage |
| System Config / Rates | None | Read (Public rates) | Read (Public rates) | Read Only | Read / Write |

---

## 3. Row Level Security (RLS) Policy Specifications

Every table in the Nectar database enforces PostgreSQL Row Level Security (`ALTER TABLE <name> ENABLE ROW LEVEL SECURITY;`).

### 3.1 User & Identity Tables
```sql
-- profiles
CREATE POLICY "profiles_select_public" ON profiles
  FOR SELECT USING (
    is_suspended = false 
    AND id NOT IN (SELECT blocked_user_id FROM user_blocks WHERE user_id = auth.uid())
    AND id NOT IN (SELECT user_id FROM user_blocks WHERE blocked_user_id = auth.uid())
  );

CREATE POLICY "profiles_update_own" ON profiles
  FOR UPDATE USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND role = (SELECT role FROM profiles WHERE id = auth.uid())); -- Prevent role escalation

-- creator_profiles
CREATE POLICY "creators_select_verified" ON creator_profiles
  FOR SELECT USING (is_active = true OR user_id = auth.uid());

CREATE POLICY "creators_update_own" ON creator_profiles
  FOR UPDATE USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());
```

### 3.2 Wallet & Financial Tables
```sql
-- coin_wallets
CREATE POLICY "wallets_select_own" ON coin_wallets
  FOR SELECT USING (user_id = auth.uid());

-- Disallow client direct INSERT/UPDATE/DELETE on coin_wallets:
-- Wallets can ONLY be mutated via server-side stored procedures or service-role handlers.
CREATE POLICY "wallets_deny_client_mutation" ON coin_wallets
  FOR ALL TO authenticated USING (false);

-- wallet_transactions
CREATE POLICY "transactions_select_own" ON wallet_transactions
  FOR SELECT USING (wallet_id IN (SELECT id FROM coin_wallets WHERE user_id = auth.uid()));

CREATE POLICY "transactions_deny_client_insert" ON wallet_transactions
  FOR INSERT TO authenticated WITH CHECK (false);

-- creator_earnings
CREATE POLICY "earnings_select_own" ON creator_earnings
  FOR SELECT USING (creator_id IN (SELECT id FROM creator_profiles WHERE user_id = auth.uid()));

-- payout_requests
CREATE POLICY "payouts_select_own" ON payout_requests
  FOR SELECT USING (creator_id IN (SELECT id FROM creator_profiles WHERE user_id = auth.uid()));

CREATE POLICY "payouts_insert_own" ON payout_requests
  FOR INSERT TO authenticated WITH CHECK (
    creator_id IN (SELECT id FROM creator_profiles WHERE user_id = auth.uid())
  );
```

### 3.3 Voice Calls & Signalling
```sql
-- call_sessions
CREATE POLICY "calls_select_participants" ON call_sessions
  FOR SELECT USING (auth.uid() = caller_id OR auth.uid() = callee_id);

CREATE POLICY "calls_insert_caller" ON call_sessions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = caller_id);

CREATE POLICY "calls_update_participants" ON call_sessions
  FOR UPDATE USING (auth.uid() = caller_id OR auth.uid() = callee_id);
```

### 3.4 Messaging & Social Safety
```sql
-- direct_messages
CREATE POLICY "messages_select_participants" ON direct_messages
  FOR SELECT USING (
    auth.uid() = sender_id OR auth.uid() = recipient_id
  );

CREATE POLICY "messages_insert_sender" ON direct_messages
  FOR INSERT TO authenticated WITH CHECK (
    auth.uid() = sender_id
    AND recipient_id NOT IN (SELECT blocked_user_id FROM user_blocks WHERE user_id = auth.uid())
    AND recipient_id NOT IN (SELECT user_id FROM user_blocks WHERE blocked_user_id = auth.uid())
  );

-- user_blocks
CREATE POLICY "blocks_manage_own" ON user_blocks
  FOR ALL USING (auth.uid() = user_id);

-- moderation_reports
CREATE POLICY "reports_insert_reporter" ON moderation_reports
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = reporter_id);
```

---

## 4. Financial Security & Transaction Integrity

### 4.1 Double-Entry Immutable Ledger
To prevent coin forgery, phantom balances, or balance drifting:
1. `coin_wallets.balance_coins` is a cached balance protected by high-concurrency pessimistic locking.
2. Every modification to `balance_coins` MUST be accompanied by an atomic record in `wallet_transactions`.
3. Periodic database reconciliation jobs assert:
   $$\text{balance\_coins} = \sum (\text{credits}) - \sum (\text{debits})$$
   Any discrepancy triggers an immediate security alert and freezes wallet operations.

### 4.2 Pessimistic Concurrency Control (`SELECT FOR UPDATE`)
When debiting coins for call per-minute billing or virtual gift dispatch, race conditions (e.g. sending two 500-coin gifts simultaneously when only 600 coins are available) are mitigated via row-level locks:
```sql
-- Executed inside a SERIALIZABLE or READ COMMITTED PostgreSQL transaction
SELECT id, balance_coins 
FROM coin_wallets 
WHERE user_id = p_user_id 
FOR UPDATE;

IF v_balance < p_required_coins THEN
  RAISE EXCEPTION 'INSUFFICIENT_FUNDS';
END IF;

UPDATE coin_wallets 
SET balance_coins = balance_coins - p_required_coins,
    updated_at = NOW()
WHERE id = v_wallet_id;

INSERT INTO wallet_transactions (...) VALUES (...);
```

### 4.3 Webhook Idempotency & Cryptographic Verification
Razorpay webhooks (`payment.captured`, `order.paid`) are processed under strict safeguards:
1. **Signature Verification:**
   ```typescript
   const expectedSignature = crypto
     .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET!)
     .update(rawBody)
     .digest('hex');
   
   if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
     throw new UnauthorizedException('Invalid webhook signature');
   }
   ```
2. **Idempotency Key:** The Razorpay `event_id` and `payment_id` are stored in an idempotent webhook processing table:
   ```sql
   CREATE TABLE processed_webhooks (
     id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
     event_id VARCHAR(100) UNIQUE NOT NULL,
     provider VARCHAR(50) NOT NULL,
     processed_at TIMESTAMPTZ DEFAULT NOW()
   );
   ```
   If `event_id` already exists, the server immediately returns `HTTP 200 OK` without re-crediting coins.

---

## 5. Media & Voice Security (LiveKit WebRTC)

1. **Short-Lived Room Scoped Tokens:**
   - Client never connects to LiveKit with permanent or broad credentials.
   - Access tokens have an expiration of **600 seconds (10 minutes)** for initial connection, renewable via server ping during active calls.
   - Tokens grant permissions strictly to the assigned room:
     ```json
     {
       "sub": "user-uuid",
       "video": {
         "room": "call-session-uuid",
         "roomJoin": true,
         "canPublish": true,
         "canSubscribe": true,
         "canPublishData": true
       }
     }
     ```
2. **End-to-End Transport Security:**
   - All signalling traffic travels over TLS (WSS).
   - All audio/video media streams are encrypted using DTLS-SRTP (RFC 5764) directly between participants and the LiveKit Selective Forwarding Unit (SFU).
3. **No Unmoderated Eavesdropping:**
   - Room participation events (`participant_joined`, `participant_left`) are validated against active `call_sessions` records.
   - If an unauthorized participant attempts to subscribe to room media, the LiveKit server webhook triggers room closure.

---

## 6. Privacy & Legal Compliance (India DPDP Act 2023)

### 6.1 Age Verification & 18+ Protection
1. **Digital Personal Data Protection Act (DPDP) 2023 Compliance:**
   - Under Section 9 of the DPDP Act 2023, processing personal data of children (<18) requires verifiable parental consent. Nectar is strictly an **Adults-Only (18+)** platform.
   - Onboarding requires an explicit, immutable declaration:
     - `age_declared_18_plus = true`
     - Timestamp of declaration recorded in `profiles.age_verified_at`
     - IP address and user-agent recorded in `audit_logs` at time of declaration.
   - If a user attempts to change their declared age below 18 or reports indicate a minor, the account is immediately suspended.

### 6.2 Data Minimization & PII Protection
1. **Phone Numbers:**
   - Stored strictly in `auth.users` (managed by Supabase Auth).
   - Stripped from public profile responses. Displayed to users only as masked strings (`+91 98*** **321`).
2. **Geolocation:**
   - Exact latitude/longitude is never stored in public profile tables.
   - Only coarse location (City, State, e.g. "Hyderabad, Telangana") is stored and rendered.
3. **Bank Account & UPI Details:**
   - Creator payout details (UPI VPA, IFSC, Account Number) are stored in encrypted columns with limited moderator view.
   - Account numbers are masked on display (`••••••••4092`).

### 6.3 Right to Erasure & Account Deletion
1. When a user requests account deletion:
   - Profile information, avatars, voice notes, and messages are permanently purged or anonymized.
   - Financial ledger entries (`wallet_transactions`, `purchase_orders`, `payout_requests`) are retained with anonymized foreign keys to comply with Indian financial and taxation audit requirements (Income Tax Act & PMLA guidelines for 7-year audit retention).

---

## 7. AI & Content Moderation Safety

1. **Gemini Safety Filters:**
   - User profile bios, voice note transcripts, and reported chat messages are analyzed via Gemini API safety classifications:
     - Harassment
     - Hate Speech
     - Sexually Explicit Material
     - Dangerous Content
   - High-severity detections trigger automated temporary hold and route to the human moderator dashboard.
2. **Zero Client-Side LLM Credentials:**
   - Gemini API keys are never exposed to the client.
   - All moderation prompts and inspection routines run inside Next.js server actions / route handlers.

---

## 8. Incident Response & Audit Logging

1. **Immutable Audit Logs:**
   The `audit_logs` table records sensitive operational events:
   - Account suspensions / unsuspensions
   - Moderator interventions
   - High-value coin purchases (> ₹2,000)
   - Creator payout approvals / rejections
   - Manual balance adjustments
2. **Rate Limiting & Abuse Prevention:**
   - Next.js route handlers implement IP-based and User-ID-based sliding window rate limits:
     - OTP Requests: 3 per 10 minutes
     - Call Initiation: 10 per hour
     - Discovery Swipes: 120 per minute
     - Direct Messages: 30 per minute
   - Exceeding thresholds results in `HTTP 429 Too Many Requests`.
