# Nectar — API & Server Actions Architecture

> **Milestone:** Gate 05B Architectural Baseline  
> **Framework:** Next.js 16.4.5 App Router Route Handlers (`src/app/api/*`) & Server Actions  
> **Protocol:** HTTPS REST (JSON), Server-Sent Events (SSE), WebSockets  
> **Validation Standard:** Zod Runtime Schema Validation

---

## 1. API Architecture Overview

Nectar utilizes Next.js App Router **Route Handlers** for webhook listeners, media token issuance, and binary streaming, combined with typed **Server Actions** for form mutations:

```
┌─────────────────────────────────────────────────────────────┐
│ CLIENT INGESTION                                            │
│ • Browser UI Components ('use client')                      │
└──────────────────────────────┬──────────────────────────────┘
                               │
            ┌──────────────────┴──────────────────┐
            ▼                                     ▼
┌──────────────────────────────┐    ┌──────────────────────────────┐
│ SERVER ACTIONS (Typed RPC)   │    │ ROUTE HANDLERS (HTTPS REST)  │
│ • initiateCallAction()       │    │ • POST /api/livekit/token    │
│ • sendGiftAction()           │    │ • POST /api/livekit/webhook  │
│ • submitPayoutAction()       │    │ • POST /api/razorpay/webhook │
│ • blockUserAction()          │    │ • POST /api/payments/order   │
└──────────────┬───────────────┘    └──────────────┬───────────────┘
               │                                   │
               └─────────────────┬─────────────────┘
                                 ▼
┌─────────────────────────────────────────────────────────────┐
│ TRUSTED SERVER SERVICE LAYER (Input Sanitization & Zod)     │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. API Route Endpoint Inventory

### 2.1 WebRTC & LiveKit Voice Endpoints

#### `POST /api/livekit/token`
- **Purpose:** Issues scoped LiveKit JWT connection token to authorized callers.
- **Access:** Authenticated Users (`is_age_verified = true`).
- **Request Payload:**
  ```json
  {
    "room_name": "call_9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    "host_user_id": "8f321b14-0e12-4f81-a9e4-53994a69daeb"
  }
  ```
- **Validation Logic:**
  1. Verify caller session (`auth.uid()`).
  2. Verify host is online and not engaged in another active call.
  3. Verify neither party has blocked the other in `user_blocks`.
  4. Verify caller's `user_wallets.coin_balance >= host.call_rate`.
- **Response (200 OK):**
  ```json
  {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "ws_url": "wss://nectar-dev.livekit.cloud",
    "call_session_id": "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    "coin_rate_per_min": 20
  }
  ```

#### `POST /api/livekit/webhook`
- **Purpose:** Ingests authoritative room lifecycle events from LiveKit SFU.
- **Access:** LiveKit Server (Verified via `Authorization` header containing LiveKit SHA-256 signature).
- **Handled Events:**
  - `participant_joined`: Updates `call_sessions.connected_at = NOW()`, status = `connected`.
  - `participant_left`: Records participant departure timestamp.
  - `room_finished`: Computes billable duration, reconciles holds, executes final ledger debits, and credits creator revenue.

---

### 2.2 Payment & Virtual Economy Endpoints

#### `POST /api/payments/create-order`
- **Purpose:** Creates a cryptographically signed Razorpay Order for coin package top-ups.
- **Access:** Authenticated Users.
- **Request Payload:**
  ```json
  {
    "package_id": "pack_popular"
  }
  ```
- **Response (200 OK):**
  ```json
  {
    "order_id": "order_EKfLsu8Pq4ZG9v",
    "amount_inr": 199.00,
    "amount_paise": 19900,
    "currency": "INR",
    "key_id": "rzp_test_xxxxxxxx"
  }
  ```

#### `POST /api/razorpay/webhook`
- **Purpose:** Ingests server-to-server payment notifications from Razorpay India rails.
- **Access:** Razorpay Server (Verified via `X-Razorpay-Signature` HMAC SHA-256).
- **Processing Logic:**
  1. Verify raw request body against `RAZORPAY_WEBHOOK_SECRET`.
  2. Extract `payment_id = payload.payment.entity.id`.
  3. Query `wallet_ledger` for `idempotency_key = payment_id`. If exists, return HTTP 200 immediately (prevent double crediting).
  4. In a single PostgreSQL transaction:
     - Insert row into `wallet_ledger` (`amount = 275`, `transaction_type = 'purchase_credit'`).
     - Increment `user_wallets.coin_balance`.
     - Update `coin_purchase_orders` status = `captured`.
  5. Push balance refresh event to user's Supabase Realtime channel.
- **Response:** `{"status": "ok", "credited": true}`

---

### 2.3 Discovery & User Feed Endpoints

#### `GET /api/discovery/feed`
- **Purpose:** Returns active, available user profiles for the discovery grid.
- **Query Parameters:**
  - `language`: 'all' | 'te' | 'hi' | 'en'
  - `limit`: number (default: 20)
  - `cursor`: string (pagination timestamp)
- **Response (200 OK):**
  ```json
  {
    "users": [
      {
        "id": "8f321b14-0e12-4f81-a9e4-53994a69daeb",
        "displayName": "Ananya Rao",
        "avatarUrl": "https://images.unsplash.com/photo-...",
        "bio": "Late night Telugu movie debater...",
        "age": 23,
        "primaryLanguage": "te",
        "supportedLanguages": ["te", "en"],
        "interests": ["Tollywood", "Late Night Talks"],
        "location": "Hyderabad, India",
        "isOnline": true,
        "isVerified": true,
        "callRatePerMin": 20
      }
    ],
    "next_cursor": "2026-11-04T02:00:00Z"
  }
  ```

---

### 2.4 Safety & Moderation Endpoints

#### `POST /api/moderation/report`
- **Purpose:** Submits an incident report ticket and queues it for Gemini AI evaluation.
- **Request Payload:**
  ```json
  {
    "reported_user_id": "8f321b14-0e12-4f81-a9e4-53994a69daeb",
    "reason": "inappropriate_audio",
    "description": "User made abusive romantic comments.",
    "call_session_id": "9b1deb4d-3b7d-4bad-9bdd-2b0d7b3dcb6d",
    "block_user_immediately": true
  }
  ```
- **Response (201 Created):**
  ```json
  {
    "ticket_id": "rep_98124bca",
    "status": "pending",
    "blocked": true
  }
  ```

---

## 3. Standardized Error Response Format

All API errors adhere to RFC 7807 Problem Details:

```json
{
  "type": "https://nectar.app/errors/insufficient-balance",
  "title": "Insufficient Coin Balance",
  "status": 402,
  "detail": "Your current coin balance (10 coins) is insufficient for the requested call rate (20 coins/min).",
  "instance": "/api/livekit/token",
  "code": "INSUFFICIENT_FUNDS",
  "required_coins": 20,
  "available_coins": 10
}
```
