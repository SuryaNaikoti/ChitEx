# Nectar — Backend Integration Execution Plan

> **Milestone:** Gate 05B Architectural Baseline  
> **Target Release:** Gate 06 Phased Implementation  
> **Auditor:** Principal Software Architect & Backend Architect

---

## 1. Integration Phasing Overview

Backend integration will proceed in five strictly sequenced, non-disruptive phases. Each phase concludes with explicit verification tests before unlocking the subsequent phase:

```
┌─────────────────────────────────────────────────────────────┐
│ Phase 1: SDK Installation & Environment Scaffolding         │
│ • Install @supabase/supabase-js, livekit-server-sdk,       │
│   livekit-client, razorpay, zod                             │
│ • Configure non-production test credentials in .env         │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ Phase 2: Supabase Relational Schema & Identity              │
│ • Execute PostgreSQL DDL migrations (Tables, Enums, RLS)    │
│ • Configure Supabase Auth (SMS OTP + Google OAuth)          │
│ • Wire 18+ Age Assurance audit records                      │
│ • Wire User Profiles & Language Discovery Feed              │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ Phase 3: Razorpay India Payments & Atomic Ledger            │
│ • Mount POST /api/payments/create-order                     │
│ • Mount Webhook POST /api/razorpay/webhook (HMAC SHA-256)   │
│ • Implement double-entry wallet ledger & concurrency locks  │
│ • Wire WalletView to live database balance                  │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ Phase 4: LiveKit WebRTC & Server-Authoritative Call Billing │
│ • Mount Server Token Endpoint POST /api/livekit/token       │
│ • Replace mock audio with livekit-client room audio streams │
│ • Mount Webhook POST /api/livekit/webhook                   │
│ • Implement server 60s billing pulses & low balance chime   │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ Phase 5: Gifting, Creator Payouts & Gemini AI Safety        │
│ • Implement atomic gift dispatch (user coin -> creator INR) │
│ • Implement creator UPI withdrawal requests                 │
│ • Wire Google Gemini 2.5 Flash for automated toxicity check │
│ • Connect Moderator & Admin consoles to live audit tables   │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Phase-by-Phase Execution Details

### Phase 1: SDK Installation & Environment Setup
- **Actions:**
  1. Add `@supabase/supabase-js`, `livekit-server-sdk`, `livekit-client`, `razorpay`, and `zod` to `package.json`.
  2. Populate development environment handles in `.env` (Supabase Dev Project, LiveKit Cloud Dev, Razorpay Test Mode).
- **Verification Gate:** `npm run build` and `tsc --noEmit` must pass cleanly without peer dependency conflicts.

### Phase 2: Supabase Relational Schema & Identity
- **Actions:**
  1. Apply migration `001_initial_schema.sql` to Supabase development database.
  2. Enable Row Level Security (RLS) on all 16 public tables.
  3. Create Supabase client singletons:
     - `src/lib/supabase/client.ts` (Browser client using `NEXT_PUBLIC_SUPABASE_ANON_KEY`)
     - `src/lib/supabase/server.ts` (Server client using Next.js cookies)
     - `src/lib/supabase/admin.ts` (Privileged service-role client for background workers)
  4. Connect `DiscoveryView.tsx` to live `user_profiles` table with bidirectional block filtering.
- **Verification Gate:** Query `user_profiles` from browser; confirm blocked users are omitted from result set.

### Phase 3: Razorpay Payments & Virtual Economy
- **Actions:**
  1. Implement `POST /api/payments/create-order` with input validation via Zod.
  2. Implement `POST /api/razorpay/webhook`: verify signature using `crypto.createHmac('sha256', RAZORPAY_WEBHOOK_SECRET)`.
  3. On `payment.captured`, execute atomic PostgreSQL transaction:
     - Insert row into `wallet_ledger` with unique `idempotency_key = payment_id`.
     - Increment `user_wallets.coin_balance`.
- **Verification Gate:** Trigger test UPI checkout with Razorpay Test Mode; confirm single credit entry in `wallet_ledger` and instant UI balance refresh via Supabase Realtime.

### Phase 4: LiveKit Voice Rooms & Authoritative Billing
- **Actions:**
  1. Implement `POST /api/livekit/token`:
     - Verify authenticated user session.
     - Check caller wallet: `balance >= host.call_rate`.
     - Mint scoped LiveKit JWT token with 5-minute join validity.
  2. Connect `ActiveCallModal.tsx` to LiveKit SFU: attach `RemoteAudioTrack` to browser `<audio>` element.
  3. Implement webhook receiver `POST /api/livekit/webhook`:
     - Authoritative duration recording on `participant_left` and `room_finished`.
     - Periodic server worker executing 60s billing pulses: debits caller wallet, credits creator earnings.
- **Verification Gate:** Conduct a 2-minute real voice call between two test browsers; verify exactly 2 minutes of coins debited on the server.

### Phase 5: Gifting, Payouts & Gemini AI Safety
- **Actions:**
  1. Implement `POST /api/gifts/send`:
     - Deduct coins from caller wallet via `wallet_ledger`.
     - Credit 60% of value in INR to `creator_profiles.withdrawable_inr_balance`.
     - Broadcast gift event to LiveKit room data channel for visual animation.
  2. Implement `POST /api/moderation/report`:
     - Save incident ticket to `user_reports`.
     - Dispatch transcript to Gemini 2.5 Flash API for toxicity scoring.
     - Automatically prioritize tickets with toxicity > 0.85 to the top of `ModeratorView`.
- **Verification Gate:** Submit a test report; confirm Gemini toxicity score is attached and visible in Moderator Console.
