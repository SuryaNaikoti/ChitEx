# Nectar — Database Architecture & Entity Specifications

> **Milestone:** Gate 05B Architectural Baseline  
> **Database Engine:** PostgreSQL 15+ (Supabase) with Row Level Security (RLS)  
> **Notice:** Documentation and entity planning only. No database migrations are executed in Gate 05B.

---

## 1. Entity-Relationship Overview

The database is structured to enforce strong relational integrity, immutable double-entry financial accounting, and strict Row Level Security.

```
┌─────────────────────┐       ┌──────────────────────┐       ┌──────────────────────┐
│     auth.users      │◄──────┤    user_profiles     │◄──────┤   creator_profiles   │
│  (Supabase Managed) │       │ (Display, Age, City) │       │(Withdrawable INR ₹)  │
└─────────────────────┘       └──────────┬───────────┘       └──────────┬───────────┘
                                         │                              │
         ┌───────────────────────────────┼──────────────────────────────┤
         │                               │                              │
         ▼                               ▼                              ▼
┌─────────────────────┐       ┌──────────────────────┐       ┌──────────────────────┐
│   user_languages    │       │     user_wallets     │       │creator_payout_request│
│(te, hi, en mappings)│       │ (Cached Coin Balance)│       │ (Min ₹500 Threshold) │
└─────────────────────┘       └──────────┬───────────┘       └──────────────────────┘
                                         │
                                         ▼
┌─────────────────────┐       ┌──────────────────────┐       ┌──────────────────────┐
│    call_sessions    │       │    wallet_ledger     │       │  gift_transactions  │
│(Duration, SFU Room) │       │(Immutable Ledger Log)│       │ (Rose, Chai, Crown)  │
└──────────┬──────────┘       └──────────────────────┘       └──────────────────────┘
           │
           ▼
┌─────────────────────┐       ┌──────────────────────┐       ┌──────────────────────┐
│     call_holds      │       │     user_blocks      │       │     user_reports     │
│(Atomic Hold Reserve)│       │(Bidirectional Filter)│       │ (Gemini Toxicity Log)│
└─────────────────────┘       └──────────────────────┘       └──────────────────────┘
```

---

## 2. Exhaustive Entity Specifications (17 Core Subsystems)

### 2.1 `user_profiles`
- **Purpose:** Primary public and private profile representation extending Supabase `auth.users`.
- **Important Fields:**
  - `id` (UUID, PK, FK -> `auth.users.id` ON DELETE CASCADE)
  - `display_name` (VARCHAR(50), NOT NULL)
  - `avatar_url` (TEXT, NOT NULL)
  - `bio` (VARCHAR(250), DEFAULT '')
  - `gender` (ENUM: 'male', 'female', 'non_binary', 'prefer_not_to_say')
  - `date_of_birth` (DATE, NOT NULL)
  - `is_age_verified` (BOOLEAN, NOT NULL DEFAULT FALSE)
  - `age_verified_at` (TIMESTAMPTZ)
  - `role` (ENUM: 'guest', 'user', 'creator', 'moderator', 'admin', DEFAULT 'user')
  - `status` (ENUM: 'active', 'suspended', 'banned', DEFAULT 'active')
  - `is_online` (BOOLEAN, DEFAULT FALSE)
  - `last_active_at` (TIMESTAMPTZ, DEFAULT NOW())
  - `call_rate_coins_per_min` (INT, NOT NULL DEFAULT 15 CHECK (call_rate_coins_per_min >= 10))
  - `created_at` / `updated_at` (TIMESTAMPTZ)
- **Relationships:** 1:1 with `auth.users`, 1:1 with `user_wallets`, 1:N with `user_languages`, 1:N with `call_sessions`.
- **Ownership & Access Rules:**
  - `SELECT`: Publicly readable by authenticated users where `status = 'active'`.
  - `UPDATE`: Owner only (`id = auth.uid()`), restricted from modifying `role`, `status`, or `is_age_verified`.

### 2.2 `user_languages`
- **Purpose:** Maps user fluency and preferred discovery languages (Telugu, Hindi, English).
- **Important Fields:**
  - `user_id` (UUID, FK -> `user_profiles.id` ON DELETE CASCADE)
  - `language_code` (VARCHAR(10), e.g. 'te', 'hi', 'en')
  - `is_primary` (BOOLEAN, DEFAULT FALSE)
  - Primary Key: `(user_id, language_code)`
- **Relationships:** N:1 with `user_profiles`.
- **Ownership & Access Rules:** Readable by authenticated users; editable only by profile owner.

### 2.3 `user_preferences`
- **Purpose:** Stores matching preferences, audio notification toggles, and discovery filters.
- **Important Fields:**
  - `user_id` (UUID, PK, FK -> `user_profiles.id`)
  - `preferred_language_codes` (VARCHAR(10)[])
  - `preferred_gender` (VARCHAR(20))
  - `allow_stranger_calls` (BOOLEAN, DEFAULT TRUE)
  - `sound_effects_enabled` (BOOLEAN, DEFAULT TRUE)
- **Ownership & Access Rules:** Read/Write exclusively by profile owner (`user_id = auth.uid()`).

### 2.4 `creator_profiles`
- **Purpose:** Tracks creator approval status, withdrawable fiat earnings, and payout KYC details.
- **Important Fields:**
  - `user_id` (UUID, PK, FK -> `user_profiles.id` ON DELETE CASCADE)
  - `approval_status` (ENUM: 'pending', 'approved', 'rejected', DEFAULT 'approved')
  - `revenue_share_percentage` (NUMERIC(5,2), NOT NULL DEFAULT 60.00)
  - `withdrawable_inr_balance` (NUMERIC(10,2), NOT NULL DEFAULT 0.00 CHECK (withdrawable_inr_balance >= 0))
  - `lifetime_inr_earned` (NUMERIC(10,2), NOT NULL DEFAULT 0.00)
  - `payout_upi_id` (VARCHAR(100))
  - `payout_bank_account` (VARCHAR(50))
  - `payout_ifsc_code` (VARCHAR(20))
  - `pan_number` (VARCHAR(20)) // Tax withholding compliance
- **Ownership & Access Rules:**
  - `SELECT`: Owner can view own profile (`user_id = auth.uid()`); Admins can view all.
  - `UPDATE`: Balance updates restricted strictly to server service-role triggers.

### 2.5 `match_queue`
- **Purpose:** Active queue entries for random voice matchmaking.
- **Important Fields:**
  - `id` (UUID, PK)
  - `user_id` (UUID, FK -> `user_profiles.id`, UNIQUE)
  - `queue_language` (VARCHAR(10), NOT NULL)
  - `status` (ENUM: 'searching', 'paired', 'accepted', 'timeout')
  - `matched_with_user_id` (UUID, FK -> `user_profiles.id`)
  - `created_at` (TIMESTAMPTZ, DEFAULT NOW())
  - `expires_at` (TIMESTAMPTZ, DEFAULT NOW() + INTERVAL '45 seconds')
- **Ownership & Access Rules:** Insert/Delete by owner; server engine executes pair matching.

### 2.6 `match_sessions`
- **Purpose:** Coordinates the 15-second mutual acceptance handshake between paired users.
- **Important Fields:**
  - `id` (UUID, PK)
  - `participant_one_id` (UUID, FK -> `user_profiles.id`)
  - `participant_two_id` (UUID, FK -> `user_profiles.id`)
  - `participant_one_status` (ENUM: 'pending', 'accepted', 'declined')
  - `participant_two_status` (ENUM: 'pending', 'accepted', 'declined')
  - `created_at` (TIMESTAMPTZ)
  - `expires_at` (TIMESTAMPTZ, DEFAULT NOW() + INTERVAL '15 seconds')
- **Ownership & Access Rules:** Participants can view and submit their own acceptance status.

### 2.7 `call_sessions`
- **Purpose:** Authoritative record of 1:1 LiveKit WebRTC voice calls and duration billing.
- **Important Fields:**
  - `id` (UUID, PK)
  - `room_name` (VARCHAR(100), UNIQUE, NOT NULL)
  - `caller_id` (UUID, FK -> `user_profiles.id`, NOT NULL)
  - `receiver_id` (UUID, FK -> `user_profiles.id`, NOT NULL)
  - `coin_rate_per_min` (INT, NOT NULL)
  - `status` (ENUM: 'initiating', 'ringing', 'connected', 'ended_normal', 'ended_insufficient_funds', 'ended_declined')
  - `started_at` (TIMESTAMPTZ)
  - `connected_at` (TIMESTAMPTZ)
  - `ended_at` (TIMESTAMPTZ)
  - `duration_seconds` (INT, NOT NULL DEFAULT 0)
  - `total_coins_billed` (INT, NOT NULL DEFAULT 0)
  - `creator_earnings_inr` (NUMERIC(10,2), NOT NULL DEFAULT 0.00)
- **Ownership & Access Rules:**
  - `SELECT`: Only caller or receiver (`caller_id = auth.uid() OR receiver_id = auth.uid()`).
  - `INSERT / UPDATE`: Restricted strictly to server service-role API.

### 2.8 `call_holds`
- **Purpose:** Pre-authorized wallet reservation hold preventing overdrafts during active calls.
- **Important Fields:**
  - `id` (UUID, PK)
  - `call_session_id` (UUID, FK -> `call_sessions.id` ON DELETE CASCADE)
  - `user_id` (UUID, FK -> `user_profiles.id`)
  - `held_coins` (INT, NOT NULL)
  - `is_settled` (BOOLEAN, DEFAULT FALSE)
  - `created_at` (TIMESTAMPTZ)
- **Ownership & Access Rules:** Service-role execution only.

### 2.9 `user_wallets`
- **Purpose:** Materialized balance cache for rapid client queries.
- **Important Fields:**
  - `user_id` (UUID, PK, FK -> `user_profiles.id` ON DELETE CASCADE)
  - `coin_balance` (INT, NOT NULL DEFAULT 0 CHECK (coin_balance >= 0))
  - `lifetime_purchased` (INT, DEFAULT 0)
  - `lifetime_spent` (INT, DEFAULT 0)
  - `updated_at` (TIMESTAMPTZ)
- **Ownership & Access Rules:**
  - `SELECT`: Owner only (`user_id = auth.uid()`).
  - `INSERT / UPDATE`: Restricted strictly to database triggers responding to `wallet_ledger`.

### 2.10 `wallet_ledger`
- **Purpose:** Immutable double-entry append-only transaction ledger.
- **Important Fields:**
  - `id` (UUID, PK, DEFAULT uuid_generate_v4())
  - `user_id` (UUID, FK -> `user_profiles.id`, NOT NULL)
  - `transaction_type` (ENUM: 'purchase_credit', 'call_debit', 'gift_sent_debit', 'admin_grant', 'refund_credit')
  - `amount` (INT, NOT NULL) // Positive for credit, negative for debit
  - `balance_after` (INT, NOT NULL)
  - `reference_id` (VARCHAR(100), NOT NULL) // payment_id, call_session_id, or gift_id
  - `idempotency_key` (VARCHAR(100), UNIQUE, NOT NULL)
  - `description` (TEXT)
  - `created_at` (TIMESTAMPTZ, NOT NULL DEFAULT NOW())
- **Ownership & Access Rules:**
  - `SELECT`: Owner only.
  - `UPDATE / DELETE`: Forbidden (`ON DELETE RESTRICT`, `ON UPDATE RESTRICT`).

### 2.11 `coin_packages`
- **Purpose:** Catalogue of official coin top-up packages in INR.
- **Important Fields:**
  - `id` (VARCHAR(50), PK, e.g. 'pack_starter')
  - `name` (VARCHAR(100), NOT NULL)
  - `coin_amount` (INT, NOT NULL)
  - `bonus_coins` (INT, NOT NULL DEFAULT 0)
  - `price_inr` (NUMERIC(10,2), NOT NULL)
  - `is_active` (BOOLEAN, NOT NULL DEFAULT TRUE)
  - `badge_label` (VARCHAR(50))
- **Ownership & Access Rules:** Publicly readable; editable only by Admins.

### 2.12 `coin_purchase_orders`
- **Purpose:** Tracks Razorpay payment orders from creation to capture.
- **Important Fields:**
  - `id` (UUID, PK)
  - `user_id` (UUID, FK -> `user_profiles.id`)
  - `package_id` (VARCHAR(50), FK -> `coin_packages.id`)
  - `razorpay_order_id` (VARCHAR(100), UNIQUE, NOT NULL)
  - `razorpay_payment_id` (VARCHAR(100), UNIQUE)
  - `amount_inr` (NUMERIC(10,2), NOT NULL)
  - `status` (ENUM: 'created', 'attempted', 'captured', 'failed')
  - `created_at` / `captured_at` (TIMESTAMPTZ)
- **Ownership & Access Rules:** Readable by order owner; updated exclusively by Razorpay webhook handler.

### 2.13 `virtual_gifts`
- **Purpose:** Official catalogue of animated in-call gifts.
- **Important Fields:**
  - `id` (VARCHAR(50), PK, e.g. 'gift_rose', 'gift_crown')
  - `name` (VARCHAR(100), NOT NULL)
  - `coin_price` (INT, NOT NULL)
  - `icon` (VARCHAR(10), NOT NULL)
  - `animation_type` (VARCHAR(50), NOT NULL)
  - `is_active` (BOOLEAN, DEFAULT TRUE)
- **Ownership & Access Rules:** Publicly readable.

### 2.14 `gift_transactions`
- **Purpose:** Records user-to-creator gift events with revenue splits.
- **Important Fields:**
  - `id` (UUID, PK)
  - `sender_id` (UUID, FK -> `user_profiles.id`)
  - `recipient_id` (UUID, FK -> `user_profiles.id`)
  - `gift_id` (VARCHAR(50), FK -> `virtual_gifts.id`)
  - `coin_amount` (INT, NOT NULL)
  - `creator_earnings_inr` (NUMERIC(10,2), NOT NULL)
  - `call_session_id` (UUID, FK -> `call_sessions.id`)
  - `idempotency_key` (VARCHAR(100), UNIQUE, NOT NULL)
  - `created_at` (TIMESTAMPTZ)
- **Ownership & Access Rules:** Read by sender and recipient; inserted via server action.

### 2.15 `creator_payout_requests`
- **Purpose:** Tracks creator withdrawal requests and KYC payout status.
- **Important Fields:**
  - `id` (UUID, PK)
  - `creator_id` (UUID, FK -> `creator_profiles.user_id`)
  - `amount_inr` (NUMERIC(10,2), NOT NULL CHECK (amount_inr >= 500.00))
  - `status` (ENUM: 'pending', 'approved', 'processed', 'rejected')
  - `payout_method` (ENUM: 'upi', 'bank_transfer')
  - `destination_details` (TEXT, NOT NULL)
  - `admin_notes` (TEXT)
  - `created_at` / `processed_at` (TIMESTAMPTZ)
- **Ownership & Access Rules:** Created and viewed by creator; updated by Admins.

### 2.16 `user_blocks` & `user_reports`
- **Purpose:** Enforces bidirectional blocking and records moderation tickets with Gemini AI toxicity scoring.
- **Important Fields (`user_blocks`):**
  - `blocker_id` (UUID, FK -> `user_profiles.id`)
  - `blocked_id` (UUID, FK -> `user_profiles.id`)
  - Unique Constraint: `(blocker_id, blocked_id)`
- **Important Fields (`user_reports`):**
  - `id` (UUID, PK)
  - `reporter_id` (UUID, FK -> `user_profiles.id`)
  - `reported_id` (UUID, FK -> `user_profiles.id`)
  - `reason` (ENUM: 'harassment', 'inappropriate_audio', 'underage', 'spam', 'impersonation')
  - `description` (TEXT)
  - `gemini_toxicity_score` (NUMERIC(4,3)) // 0.000 to 1.000
  - `gemini_summary` (TEXT)
  - `status` (ENUM: 'pending', 'warned', 'suspended', 'banned', 'dismissed')
- **Ownership & Access Rules:**
  - Blocks: Blocker can view their blocked list; blocked user cannot view the record.
  - Reports: Reporter can create; only Moderators and Admins can view and resolve.

### 2.17 `admin_audit_logs`
- **Purpose:** Immutable compliance audit trail of administrative and moderator actions.
- **Important Fields:**
  - `id` (UUID, PK)
  - `actor_id` (UUID, FK -> `user_profiles.id`)
  - `action_type` (VARCHAR(50), e.g. 'user_banned', 'payout_approved', 'pricing_updated')
  - `target_entity_id` (VARCHAR(100))
  - `metadata` (JSONB)
  - `created_at` (TIMESTAMPTZ, DEFAULT NOW())
- **Ownership & Access Rules:** Read-only for Super Admins; insertable exclusively via server service-role.
