# Nectar — System Architecture Blueprint

> **Milestone:** Gate 05B Architectural Baseline  
> **Framework:** Next.js 16.4.5 App Router (Full-Stack Monolith)  
> **Target Market:** India (Telugu, Hindi, English)  
> **Runtime Environment:** Containerized Node.js (Port 3000)  
> **Status:** APPROVED ARCHITECTURAL SPECIFICATION

---

## 1. Architectural Vision & Topology

Nectar is architected as a **Server-Authoritative Modular Monolith** built on the **Next.js 16 App Router**. Rather than deploying fragmented microservices prematurely, all domain modules reside within a unified codebase with clean layer boundaries, strict server-only privileged execution paths, and asynchronous event reconciliation.

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           CLIENT LAYER (Next.js 16 PWA)                                 │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌─────────────────────────────┐  │
│  │ User Discovery Feed   │  │ Voice Match Radar     │  │ Intimate Live Call Screen   │  │
│  │ (Portrait Cards,      │  │ (Pulsing Rings,       │  │ (LiveKit WebRTC,            │  │
│  │  Voice Note Previews) │  │  Handshake 15s Timer) │  │  Mic Visualizer, Timer)     │  │
│  └───────────────────────┘  └───────────────────────┘  └─────────────────────────────┘  │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌─────────────────────────────┐  │
│  │ Coin Wallet & Store   │  │ Host Earnings Hub     │  │ Safety & Admin Consoles     │  │
│  │ (Apple Wallet Style,  │  │ (Withdrawable INR,    │  │ (Gemini AI Toxicity,        │  │
│  │  Razorpay Checkout)   │  │  UPI Payout Requests) │  │  Audit Logs, 1-Click Ban)   │  │
│  └───────────────────────┘  └───────────────────────┘  └─────────────────────────────┘  │
└────────────────────────────────────────────┬────────────────────────────────────────────┘
                                             │ HTTPS REST / WebSocket / Server Actions
                                             ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                   SERVER-AUTHORITATIVE SERVICE LAYER (Next.js App Router)               │
│  ┌───────────────────────────────────────────────────────────────────────────────────┐  │
│  │ Route Handlers (src/app/api/*):                                                   │  │
│  │ • /api/auth/session               • /api/livekit/token    • /api/livekit/webhook  │  │
│  │ • /api/payments/create-order      • /api/razorpay/webhook • /api/moderation/check │  │
│  └───────────────────────────────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌─────────────────────────────┐  │
│  │ AuthService           │  │ MatchingEngine        │  │ CallBillingEngine           │  │
│  │ (OTP Rate Limiting,   │  │ (Language Affinity,   │  │ (Server 60s Ticks,          │  │
│  │  Age Verification 18+)│  │  Mutual Block Checks) │  │  Holds & Reconciliations)   │  │
│  └───────────────────────┘  └───────────────────────┘  └─────────────────────────────┘  │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌─────────────────────────────┐  │
│  │ WalletLedgerService   │  │ GiftEngine            │  │ ModerationPipeline          │  │
│  │ (Atomic ACID DB Locks,│  │ (Coin Burn, Creator   │  │ (Gemini 2.5 Flash Scoring,  │  │
│  │  Immutable Double-Ent)│  │  Revenue Split INR)   │  │  Incident Triaging)         │  │
│  └───────────────────────┘  └───────────────────────┘  └─────────────────────────────┘  │
└───────┬────────────────────────────┬─────────────────────────────┬──────────────────────┘
        │                            │                             │
        ▼                            ▼                             ▼
┌────────────────────────┐  ┌────────────────────────┐  ┌─────────────────────────────┐
│  SUPABASE POSTGRESQL   │  │     LIVEKIT CLOUD      │  │      RAZORPAY INDIA         │
│ • Row Level Security   │  │ • WebRTC Audio SFU     │  │ • Payment Orders API        │
│ • Supabase Auth (JWT)  │  │ • Room Lifecycle Hooks │  │ • Webhook HMAC SHA-256      │
│ • Supabase Realtime WS │  │ • Dynamic JWT Tokens   │  │ • UPI, Cards, NetBanking    │
│ • Supabase Storage S3  │  │ • Opus Voice Codecs    │  │ • Idempotent Settlements    │
└────────────────────────┘  └────────────────────────┘  └─────────────────────────────┘
```

---

## 2. Core Architectural Principles

1. **Zero Client Trust for Financial Calculations:**
   - The browser client is strictly a presentation terminal.
   - All coin balance modifications, call duration calculations, gift splits, and payout computations are performed exclusively in server-side Node.js code wrapped in PostgreSQL database transactions (`BEGIN...COMMIT`) with row-level locks (`SELECT ... FOR UPDATE`).
2. **Server-Minted Ephemeral WebRTC Tokens:**
   - WebRTC audio room access is granted exclusively through short-lived (< 5 minutes) cryptographically signed LiveKit JWTs minted by the Next.js server.
   - Tokens are minted only after pre-flight authorization: caller wallet balance >= host call rate, zero active bidirectional blocks, and room status verification.
3. **Double-Entry Append-Only Financial Ledger:**
   - User wallet balances are materialized caches backed by the immutable, append-only `wallet_ledger` table.
   - Deletions and updates on ledger rows are strictly forbidden at the database level (`ON DELETE RESTRICT`, `ON UPDATE RESTRICT`).
4. **Decoupled Virtual Economy (Coins vs. Creator INR):**
   - User Coins (non-withdrawable in-app tokens) are purchased via fiat INR.
   - Creator Earnings (withdrawable fiat INR) are accrued strictly when receiving virtual gifts. A coin's purchase price never directly equals a creator's payout value.
5. **Defense-in-Depth Privacy & Identity Protection:**
   - E.164 phone numbers (`+91`), OAuth identity tokens, IP addresses, and exact geolocation are never exposed in public views or API payloads.
   - Public user endpoints serialize only verified display names, avatar URLs, language arrays, and broad city locations (e.g. "Hyderabad, India").
6. **Bidirectional Block Isolation:**
   - Blocking a user immediately terminates ongoing LiveKit WebRTC sessions and suppresses all data visibility bidirectionally in database queries and Supabase Realtime event streams.

---

## 3. Technology Stack & Runtime Profile

| Layer | Component | Runtime / Library | Architectural Role |
|---|---|---|---|
| **Frontend Framework** | Next.js 16.4.5 (App Router) | React 19, Turbopack | Server & Client Components, PWA layout, SSR |
| **Styling & Design** | Tailwind CSS v4 | `@tailwindcss/postcss`, PostCSS | Responsive mobile-first layout (`max-w-md mx-auto`) |
| **Realtime Audio SFU** | LiveKit Cloud | `livekit-client`, `livekit-server-sdk` | Ultra-low latency voice mesh, room lifecycle hooks |
| **Relational Database** | Supabase (PostgreSQL 15+) | `@supabase/supabase-js` | Relational tables, triggers, Row Level Security |
| **Identity & Auth** | Supabase Auth | SMS OTP (+91), Google OAuth, JWT | User identity, session tokens, RBAC claims |
| **Data Streaming** | Supabase Realtime | WebSocket (`pg_notify`) | Presence heartbeats, call ringing, 1:1 chat |
| **Payment Gateway** | Razorpay Node SDK | `razorpay` | UPI, NetBanking, cards, HMAC signature verification |
| **Moderation AI** | Google Gemini API | `@google/genai` (Gemini 2.5 Flash) | Automated bio screening & reported audio transcript scoring |
| **Audio Synthesis** | Browser Web Audio API | `SoundEngine` class | Zero-latency dial tones, connect chimes, fanfare |

---

## 4. Network Boundaries & Execution Contexts

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ UNTRUSTED ZONE: Public Internet & Web Client (Browser)                                  │
│ • Next.js Client Components ('use client')                                              │
│ • Public Environment Variables (NEXT_PUBLIC_*)                                          │
│ • Local React State (UI tabs, animation toggles, audio visualizers)                     │
└────────────────────────────────────────────┬────────────────────────────────────────────┘
                                             │ HTTPS TLS 1.3 / WSS
                                             ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ DMZ: Next.js Server Boundaries (App Router API Routes & Server Actions)                 │
│ • Input validation via Zod schemas                                                      │
│ • Rate limiting (Upstash Redis / in-memory sliding window)                              │
│ • Cookie & Bearer JWT validation                                                        │
│ • Webhook signature verification (Razorpay HMAC SHA-256, LiveKit SHA-256)               │
└────────────────────────────────────────────┬────────────────────────────────────────────┘
                                             │ Private Network / Service Role
                                             ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ TRUSTED ZONE: Managed Cloud Infrastructure                                              │
│ • Supabase PostgreSQL (Protected by RLS & Service-Role Secret)                          │
│ • LiveKit Server API (Protected by LIVEKIT_API_SECRET)                                  │
│ • Razorpay Orders API (Protected by RAZORPAY_KEY_SECRET)                                │
│ • Google Gemini AI Gateway (Protected by GEMINI_API_KEY)                                │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```
