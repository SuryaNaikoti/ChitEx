# Nectar — System Components Specification

> **Milestone:** Gate 05B Architectural Baseline  
> **Framework:** Next.js 16.4.5 App Router  
> **Auditor:** Principal Software Architect & Backend Architect

---

## 1. Component Layering Model

The Nectar system components are partitioned into four distinct architectural tiers:

```
┌────────────────────────────────────────────────────────────────────────┐
│ 1. PRESENTATION LAYER (Next.js Client Components - 'use client')       │
│ • RootShell & Layout (`src/app/layout.tsx`, `src/app/page.tsx`)        │
│ • Header & Navigation (`Header.tsx`, `BottomNav.tsx`)                  │
│ • Discovery Feed (`DiscoveryView.tsx`)                                 │
│ • Voice Match Radar (`MatchRadarView.tsx`)                             │
│ • Active Call Interface (`ActiveCallModal.tsx`, `CallModals.tsx`)      │
│ • Virtual Economy Views (`WalletView.tsx`, Standalone Gift Drawer)     │
│ • Direct Messaging (`MessagesView.tsx`)                                │
│ • Creator Hub (`CreatorView.tsx`)                                      │
│ • Moderation & Admin Consoles (`ModeratorView.tsx`, `AdminView.tsx`)   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Server Actions / Route Handlers
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 2. APPLICATION SERVICE LAYER (Server-Only Modules - 'server-only')     │
│ • AuthService (`src/services/auth.service.ts`)                         │
│ • UserService (`src/services/user.service.ts`)                         │
│ • MatchingEngine (`src/services/matching.service.ts`)                  │
│ • CallBillingEngine (`src/services/call-billing.service.ts`)           │
│ • WalletLedgerService (`src/services/wallet-ledger.service.ts`)        │
│ • GiftEngine (`src/services/gift.service.ts`)                          │
│ • ModerationService (`src/services/moderation.service.ts`)             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ SQL Queries / Webhooks / SDKs
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 3. PERSISTENCE & DATA ACCESS TIER (Supabase PostgreSQL 15+)            │
│ • Database Schema Repositories (`src/repositories/*.repository.ts`)    │
│ • Generated TypeScript Types (`src/types/database.types.ts`)           │
│ • Database Triggers, Functions & RLS Policies                          │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ External API Protocols
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 4. INTEGRATED EXTERNAL PLATFORMS                                       │
│ • Supabase Auth, Storage, and Realtime WebSocket Engine                │
│ • LiveKit Cloud WebRTC SFU Media Cluster                               │
│ • Razorpay India Payments Gateway                                      │
│ • Google Gemini AI Gateway (@google/genai)                             │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Frontend Component Specifications & Backend Mappings

This mapping documents how each existing UI component connects to its respective backend service endpoints:

| UI Component File | Current Mock Interaction | Target Backend Service | Server API / Route Handler |
|---|---|---|---|
| `Header.tsx` | Local language state & role switcher | `UserService`, `WalletLedgerService` | `GET /api/user/me`, `GET /api/wallet/balance` |
| `BottomNav.tsx` | Local `activeTab` switching | Next.js App Router Client Navigation | Push-state / tab dispatcher |
| `DiscoveryView.tsx` | Renders `INITIAL_USERS`, mock audio snippet | `UserService` | `GET /api/discovery/feed?lang=te` |
| `MatchRadarView.tsx`| 2.2s `setTimeout` candidate matching | `MatchingEngine` | `POST /api/match/queue`, Supabase Realtime channel `match_events` |
| `ActiveCallModal.tsx`| Local `setInterval` timer & local coin debit | `CallBillingEngine`, LiveKit SFU | `POST /api/livekit/token`, Webhook `POST /api/livekit/webhook` |
| `CallModals.tsx` | Pre-call pricing dialog & summary sheet | `CallBillingEngine` | `GET /api/calls/:id/summary` |
| `WalletView.tsx` | Local package top-up & array ledger append | `WalletLedgerService`, Razorpay | `POST /api/payments/create-order`, Webhook `POST /api/razorpay/webhook` |
| `MessagesView.tsx` | Local array append with 1.2s echo reply | `ChatService`, Supabase Realtime | `GET /api/chat/:convId`, Realtime channel `chat_messages` |
| `ProfileView.tsx` | Local state toggles (rate, availability) | `UserService` | `PATCH /api/user/profile`, `PATCH /api/user/settings` |
| `CreatorView.tsx` | Local 60% revenue calculation & UPI form | `CreatorService` | `GET /api/creator/statement`, `POST /api/creator/payout-request` |
| `ModeratorView.tsx`| Local ticket status toggle (warn/ban) | `ModerationService` | `GET /api/moderation/tickets`, `POST /api/moderation/action` |
| `AdminView.tsx` | Static KPI numbers | `AdminService` | `GET /api/admin/metrics` |

---

## 3. Server Service Layer Functional Specifications

### 3.1 AuthService (`src/services/auth.service.ts`)
- **Responsibilities:**
  - Standardizes Indian mobile numbers to E.164 (`+91XXXXXXXXXX`).
  - Enforces SMS OTP rate limits (maximum 3 dispatches per 10 minutes per IP/number) using Redis or PostgreSQL sliding windows.
  - Verifies Supabase Auth tokens and provisions initial database records.
  - Enforces mandatory 18+ age verification check: records birth year, legal declaration timestamp, and assigns initial welcome bonus.

### 3.2 MatchingEngine (`src/services/matching.service.ts`)
- **Responsibilities:**
  - Manages active matchmaking queues partitioned by language: Telugu Lounge (`te`), Hindi Charcha (`hi`), English Corner (`en`).
  - Excludes any user pair present in `user_blocks` (bidirectional filtering).
  - Pairs available users, generates temporary match session IDs, and monitors the 15-second mutual acceptance countdown.
  - Upon mutual acceptance, coordinates with `CallBillingEngine` to instantiate the LiveKit room.

### 3.3 CallBillingEngine (`src/services/call-billing.service.ts`)
- **Responsibilities:**
  - Verifies caller wallet solvency: `balance >= host_call_rate`.
  - Atomically locks caller wallet and places reservation hold (`call_holds`).
  - Requests LiveKit server to mint participant tokens with room-join capabilities.
  - Ingests LiveKit server webhooks (`participant_joined`, `participant_left`, `room_finished`).
  - Ticks billing every 60 seconds: deducts coins atomically via `WalletLedgerService`.
  - Disconnects room via LiveKit REST API when caller balance drops to 0.
  - Finalizes session: reconciles hold against actual duration, releases unbilled balance, and credits creator earnings.

### 3.4 WalletLedgerService (`src/services/wallet-ledger.service.ts`)
- **Responsibilities:**
  - Implements the double-entry bookkeeping engine.
  - All balance mutations append immutable rows to `wallet_ledger` with unique `idempotency_key`.
  - Executes atomic row-level locks on `user_wallets` using `SELECT ... FOR UPDATE`.
  - Prevents overdrafts: enforces `CHECK (coin_balance >= 0)`.

### 3.5 GiftEngine (`src/services/gift.service.ts`)
- **Responsibilities:**
  - Fetches active gift catalogue (Rose: 10🪙, Chai: 25🪙, Crown: 100🪙, Peacock: 500🪙).
  - Executes atomic transfer: debits user wallet, records gift transaction, and computes creator earnings in INR based on configurable revenue share.
  - Broadcasts full-screen gift animation event to the active call room data channel.

### 3.6 ModerationService (`src/services/moderation.service.ts`)
- **Responsibilities:**
  - Instant block enforcement: writes to `user_blocks`, terminates active voice sessions immediately, and revokes Supabase Realtime channel access.
  - Queues reported user incidents in `user_reports`.
  - Sends flagged text and transcripts to Google Gemini 2.5 Flash API for automated toxicity evaluation.
  - Provides administrative review queue with 1-click warning, 24-hour suspension, and permanent ban actions.
