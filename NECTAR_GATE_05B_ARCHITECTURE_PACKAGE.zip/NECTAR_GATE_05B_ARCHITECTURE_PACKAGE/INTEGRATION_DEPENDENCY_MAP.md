# NECTAR — Integration Dependency Map & Failure Modes Specification
**Document Reference:** `docs/architecture/INTEGRATION_DEPENDENCY_MAP.md`  
**Milestone:** Gate 05B — Backend Architecture & Integration Preparation  
**Classification:** Confidential — Engineering & System Architecture  
**Author:** Principal Software Architect, Backend Architect & Security Engineer  

---

## 1. System Integration Topology

Nectar relies on four primary external managed infrastructure platforms connected to our Next.js App Router core:

```
                          ┌──────────────────────────────────────────────┐
                          │         NECTAR NEXT.JS APP ROUTER            │
                          │   (Node.js / Edge Serverless / SSR Core)     │
                          └──────┬─────────────┬────────────┬────────────┘
                                 │             │            │
          ┌──────────────────────┼─────────────┼────────────┼──────────────────────┐
          │                      │             │            │                      │
          ▼                      ▼             ▼            ▼                      ▼
┌──────────────────┐   ┌────────────────┐  ┌────────┐  ┌─────────────┐   ┌───────────────────┐
│     SUPABASE     │   │    LIVEKIT     │  │RAZORPAY│  │  GEMINI API │   │   UPSTASH REDIS   │
│  (ap-south-1)    │   │  (India SFU)   │  │(Mumbai)│  │ (Google AI) │   │   (ap-south-1)    │
├──────────────────┤   ├────────────────┤  ├────────┤  ├─────────────┤   ├───────────────────┤
│ • PostgreSQL 16  │   │ • WebRTC Voice │  │• Orders│  │ • Text      │   │ • Sliding Window  │
│ • Supabase Auth  │   │ • Room Events  │  │• Signa-│  │   Moderation│   │   Rate Limiting   │
│ • Realtime (WSS) │   │ • SFU Audio    │  │  tures │  │ • Audio     │   │ • Match Queue     │
│ • Object Storage │   │ • Egress Logs  │  │• Hooks │  │   Filtering │   │   Transient State │
└──────────────────┘   └────────────────┘  └────────┘  └─────────────┘   └───────────────────┘
```

---

## 2. External Integration Profiles

| Provider | Purpose | Primary Protocol | Target Region | SLA Target | Latency Budget |
| :--- | :--- | :--- | :--- | :---: | :---: |
| **Supabase** | Primary relational DB, Auth, Realtime, Object Storage | HTTPS REST / WSS / PostgreSQL wire | `ap-south-1` (Mumbai) | 99.95% | < 25 ms |
| **LiveKit** | Real-time WebRTC SFU voice calling, participant events | DTLS-SRTP (Audio) / WSS (Signalling) | Mumbai / Hyderabad Edge | 99.99% | < 50 ms (audio) |
| **Razorpay** | Payment processing (UPI, Netbanking, Cards), Webhooks | HTTPS REST / HMAC Webhooks | India National Gateway | 99.9% | < 800 ms (Order) |
| **Gemini API** | Automated profile bio safety check, voice transcript moderation | HTTPS REST (`@google/genai`) | Google Global / India | 99.9% | < 1,200 ms |
| **Upstash** | Distributed rate limiting, ephemeral match queue state | HTTPS REST / Redis protocol | `ap-south-1` (Mumbai) | 99.99% | < 15 ms |

---

## 3. End-to-End Inter-System Data Flows

### 3.1 Flow A: User Discovery & Match Initiation
1. **Client** queries `/api/discovery/feed` with preferences (target languages: Telugu, Hindi, English; age range).
2. **Next.js Server** queries `profiles` and `creator_profiles` in Supabase using the user's RLS session. Filter out blocked users (`user_blocks`) and recent matches (`matches`).
3. If both users swipe right (Mutual Match), **Next.js Server** records a record in `matches` and dispatches a Supabase Realtime broadcast message on channel `presence:user-<id>`.
4. Both clients receive the match modal simultaneously with match animations.

### 3.2 Flow B: Live Voice Call Connection & Metering Loop
1. **User A** initiates a call to **Creator B** via `/api/calls/initiate`.
2. **Next.js Server** executes a pre-call check:
   - Verifies Creator B is `available` in `creator_profiles`.
   - Checks User A wallet balance in `coin_wallets`: requires at least 1 minute of call balance (`creator_profiles.call_rate_coins_per_min`).
   - Creates a pending `call_sessions` row (status: `ringing`).
   - Issues a temporary 1-minute coin hold in `call_coin_holds`.
3. **Next.js Server** generates two scoped LiveKit JWTs (one for User A, one for Creator B) with room name `call_<call_session_id>` via LiveKit Server SDK.
4. **Creator B** accepts call. LiveKit fires `participant_joined` webhook to `/api/webhooks/livekit`.
5. Next.js marks `call_sessions.status = 'active'`, `started_at = NOW()`.
6. **Active Call Metering Loop (Every 60 Seconds):**
   - LiveKit room heartbeat confirms active participants.
   - Next.js server background job or client metering pulse executes stored procedure `deduct_call_minute(call_id)`:
     - Locks `coin_wallets` (`SELECT FOR UPDATE`).
     - Debits rate from caller's wallet; creates `wallet_transactions` debit entry.
     - Computes creator share (60% provisional) and platform share (40%).
     - Accrues creator earning in `creator_earnings` (`amount_inr = coins * 0.10 * 0.60`).
   - If caller balance reaches 0, Next.js calls `RoomServiceClient.removeParticipant()` or closes the LiveKit room, gracefully disconnecting the call with `INSUFFICIENT_FUNDS_TERMINATION`.

### 3.3 Flow C: Coin Purchase & Invariant Crediting
1. **Client** requests coin package (`/api/wallet/purchase/create-order`).
2. **Next.js Server** generates a Razorpay Order (`orders.create({ amount: package.price_inr * 100, currency: 'INR' })`).
3. Next.js records a `purchase_orders` record (status: `created`). Returns `order_id` and public `key_id` to client.
4. **Client** opens Razorpay Checkout modal. User pays via UPI / QR / Card.
5. **Razorpay** invokes webhook `/api/webhooks/razorpay` with event `payment.captured`.
6. **Next.js Server**:
   - Validates webhook signature (`crypto.createHmac('sha256', RAZORPAY_WEBHOOK_SECRET)`).
   - Verifies event idempotency (`processed_webhooks`).
   - Updates `purchase_orders` status to `completed`.
   - Atomically updates `coin_wallets.balance_coins` and appends `wallet_transactions` record inside a single PostgreSQL transaction.
   - Dispatches Supabase Realtime event to notify client wallet UI to refresh with celebrated coin animation.

### 3.4 Flow D: Virtual Gift Sending During Live Call
1. User clicks gift icon (e.g. *Royal Crown*, 500 Coins) in active call UI.
2. Client posts to `/api/gifts/send` `{ call_session_id, recipient_id, gift_id }`.
3. Next.js Server executes atomic procedure:
   - Locks sender wallet (`SELECT FOR UPDATE`). Checks `balance_coins >= 500`.
   - Debits 500 coins from sender (`wallet_transactions`).
   - Calculates creator earnings:
     $$\text{INR} = 500 \times 0.10 \times 0.60 = ₹30.00$$
   - Inserts record into `virtual_gifts` and `creator_earnings`.
   - Publishes Realtime payload via Supabase Realtime channel `call:<session_id>`: `{ event: 'GIFT_ANIMATION', gift_type: 'royal_crown', sender_name: 'Rahul' }`.
4. Both participants' call screens render high-fidelity visual gift animation without interrupting WebRTC audio.

---

## 4. Failure Modes, Timeouts & Fallback Matrix

| Dependency | Failure Mode | Timeout | Retry Policy | Fallback Behavior |
| :--- | :--- | :---: | :---: | :--- |
| **Supabase PostgreSQL** | Connection pool exhaustion / DB unavailable | 5,000 ms | 3 retries, exponential backoff (100ms, 200ms, 400ms) | Return `HTTP 503 Service Unavailable`. Do not allow unrecorded transactions. Show user retry toast. |
| **Supabase Auth** | Auth service downtime / Token validation failure | 3,000 ms | 2 retries | Prompt user to re-authenticate. If refresh fails, redirect to login page. |
| **Supabase Realtime** | WebSocket disconnect (mobile network switch) | 10,000 ms | Auto-reconnect with jitter (1s - 10s) | Degrade to HTTP polling (every 5s) for match queue & call status until socket restores. |
| **LiveKit SFU** | Media node unreachable / ICE failure | 8,000 ms | Client ICE restart; server token regeneration (max 2) | Display "Reconnecting voice..." overlay. If unresolved after 15s, terminate call session and refund unused held coins. |
| **Razorpay API** | Order creation failure (Gateway timeout) | 6,000 ms | 1 immediate retry | Return error "Payment gateway temporarily busy. Please try again." Do not debit user. |
| **Razorpay Webhook** | Webhook delivery delayed or dropped | N/A | Handled by Razorpay retry schedule (up to 24h) | User app initiates manual status check `/api/wallet/purchase/verify` upon returning from gateway modal. |
| **Gemini API** | Rate limit (429) or endpoint outage (503) | 4,000 ms | 2 retries | Queue content for asynchronous batch moderation. Temporarily flag user-generated bio as `pending_review` without blocking safe onboarding. |

---

## 5. Network Latency & Regional Optimization for India

1. **Deployment Region Alignment:**
   - Next.js serverless functions and Supabase database are colocated in **AWS ap-south-1 (Mumbai)** to guarantee sub-10ms internal database query roundtrips.
2. **Audio SFU Proximity:**
   - LiveKit nodes deployed in Mumbai and Bangalore points of presence to minimize round-trip audio latency for Tier 1, Tier 2, and Tier 3 Indian mobile networks (Jio, Airtel, Vi).
   - Audio codec configured to **Opus with Adaptive Bitrate (16 kbps - 48 kbps)** with forward error correction (FEC) enabled to withstand 15% packet loss on Indian mobile data transitions.
3. **PWA Offline Resilience:**
   - Discovery cache stored in IndexedDB allows browsing previously loaded profile cards during momentary mobile connection drops.
   - Action queue holds outgoing likes/messages and syncs upon network restoration.
