# Nectar — Authentication & Identity Architecture

> **Milestone:** Gate 05B Architectural Baseline  
> **Auth Provider:** Supabase Auth (GoTrue Engine)  
> **Target Audience:** Engineering Leads & Security Architects

---

## 1. Authentication Topology & Provider Strategy

Nectar implements a multi-provider authentication architecture tailored specifically to the Indian consumer market:

```
┌─────────────────────────────────────────────────────────────┐
│ CLIENT IDENTIFIER INGESTION                                 │
│ 1. Indian Mobile Number (E.164 format: +91 XXXXX XXXXX)     │
│ 2. 1-Tap Google Identity Sign-In (OAuth 2.0 / OpenID)       │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ RATE LIMITING & ABUSE SHIELD (Server Boundary)              │
│ • Max 3 OTP dispatches per 10 minutes per IP/Phone          │
│ • Cloudflare Turnstile / reCAPTCHA v3 bot scoring           │
│ • Lockout penalty: 30 minutes on 5 consecutive failures     │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ SUPABASE AUTH ENGINE (GoTrue)                               │
│ • SMS Gateway Dispatches 6-Digit OTP via Twilio / Fast2SMS  │
│ • JWT Session Token Minting (HMAC SHA-256)                  │
│ • Access Token (1-hour TTL) + Refresh Token (30-day TTL)    │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ 18+ AGE ASSURANCE & PROFILE ATTESTATION GUARD               │
│ • Validates birth date (must be >= 18 years old)            │
│ • Records immutable attestation: is_age_verified = TRUE     │
│ • Sets httpOnly secure session cookies in Next.js           │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Session Management & Cookie Storage

- **Storage Medium:** Sessions are maintained via `httpOnly`, `secure`, `sameSite: 'lax'` cookies managed by `@supabase/ssr` in Next.js.
- **Client Access:** Client JavaScript cannot access or read raw JWT tokens directly, mitigating Cross-Site Scripting (XSS) token exfiltration attacks.
- **Token Claims Structure:**
  ```json
  {
    "sub": "3f421a8c-8f92-411a-b328-3e5f29c29801",
    "aud": "authenticated",
    "role": "authenticated",
    "email": "user@nectar.internal",
    "phone": "+919876543210",
    "app_metadata": {
      "provider": "phone",
      "user_role": "user" // 'user' | 'creator' | 'moderator' | 'admin'
    },
    "user_metadata": {
      "is_age_verified": true,
      "display_name": "Surya Teja"
    },
    "exp": 1793782800
  }
  ```

---

## 3. Role-Based Access Control (RBAC) Specification

| Role | Hierarchy Level | Capabilities & Access Permissions |
|---|:---:|---|
| **Guest** | Level 0 | Browse landing page, read community guidelines and terms, initiate login. |
| **User** | Level 1 | Access discovery feed, join voice radar queue, make/receive 1:1 voice calls, top-up coin wallet, send gifts, block & report users. Must have `is_age_verified = true`. |
| **Creator** | Level 2 | All User capabilities + host voice rooms, view virtual gift earnings statements, manage custom per-minute call rates, request UPI/bank payouts. |
| **Moderator** | Level 3 | Access `/admin/moderation`, inspect reported incident tickets, review Gemini AI toxicity scores, issue warnings, execute 24h suspensions. |
| **Super Admin** | Level 4 | Access `/admin`, manage creator approvals, review financial liability metrics, configure coin packages and gift pricing, execute permanent bans. |

---

## 4. Server-Side Route Guard Implementation Pattern

In Next.js 16, authorization checks are enforced inside Server Actions, Route Handlers, and Server Components using the authenticated Supabase server client:

```typescript
// src/lib/auth/guards.ts
import { createServerClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import { UserRole } from '@/types';

export async function requireAuth(requiredRole: UserRole = 'user') {
  const supabase = await createServerClient();
  const { data: { user }, error } = await supabase.auth.getUser();

  if (error || !user) {
    redirect('/login');
  }

  // Age verification guard (Non-negotiable 18+ platform rule)
  if (!user.user_metadata?.is_age_verified) {
    redirect('/onboarding/age');
  }

  // Role hierarchy check
  const roleHierarchy: Record<UserRole, number> = {
    user: 1,
    creator: 2,
    moderator: 3,
    admin: 4,
  };

  const currentRole = (user.app_metadata?.user_role as UserRole) || 'user';
  if (roleHierarchy[currentRole] < roleHierarchy[requiredRole]) {
    throw new Error('Forbidden: Insufficient privileges');
  }

  return { user, role: currentRole };
}
```

---

## 5. Privacy & Sensitive Field Suppression

1. **Database-Level Isolation:**  
   The `user_profiles` table does not expose raw phone numbers to standard users. A separate database view `public_user_profiles` excludes:
   - `phone_number`
   - `date_of_birth` (only calculated age integer is exposed)
   - `ip_address`
   - `created_at`
2. **Serialization Rules:**  
   Next.js API route handlers must strip internal auth IDs and ensure user display objects conform to `UserProfile` client interface.
